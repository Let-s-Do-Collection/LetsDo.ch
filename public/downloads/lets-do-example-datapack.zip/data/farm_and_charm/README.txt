Farm & Charm examples

Folder: data/farm_and_charm/

Notes:
- Only the files you want to override must exist in your datapack.
- Always copy the original JSON first and then modify it.
- For tags, use "replace": false to extend instead of wiping the list.
- Tag references need a leading # (for example: "#minecraft:campfires").
