Let’s Do - Example Datapack (Farm & Charm)

This datapack demonstrates how to override:
- Recipes
- Loot tables
- Tags
- World generation (configured + placed features)

How to use:
1. Put this ZIP’s extracted folder into:
   saves/<your_world>/datapacks/
2. In-game run: /reload
3. Verify with: /datapack list

Important:
- File paths and file names must match the original mod exactly.
- For block loot tables, the loot table file name must match the block id.
- World generation changes only apply to new chunks.
  Existing terrain will not be retroactively updated.

What this pack does:
- Recipe example: changes the output of a shaped recipe.
- Loot table example: makes Fertilized Soil drop a diamond.
- Tag example: adds diamond blocks as a valid heat source.
- Worldgen example: makes Wild Barley patches rarer via rarity_filter.
